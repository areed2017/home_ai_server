import requests
from home_ai.Task import Task


def default_api_key():
    api_key = input("Input openweathermap API key: ")
    return api_key


def get_coordinates():
    ip = requests.get('https://api.ipify.org').content.decode('utf8')
    location = requests.get(f"http://ip-api.com/json/{ip}").json()
    return location['lat'], location['lon']


class Weather(Task):
    def __init__(self, *args, **kwargs):
        super().__init__("areed2017__weather", *args, **kwargs)
        self.api_key, self.set_api_key = self.use_state(
            "api_key", default_value=default_api_key
        )
        self.coordinates, self.set_coordinates = self.use_state(
            "coordinates", default_value=get_coordinates
        )

    def run(self, *args):
        data = requests.get(
            f"https://api.openweathermap.org/data/2.5/onecall?"
            f"lat={self.coordinates[0]}&"
            f"lon={self.coordinates[1]}&"
            f"exclude=hourly,daily&"
            f"units=imperial&"
            f"appid={self.api_key}"
        ).json()

        tempature = round(data['current']['temp'])
        weather_str = data['current']['weather'][0]['description']
        self.output(
            f"The weather is currently {weather_str} with a temperature of {tempature} degrees fahrenheit"
        )


